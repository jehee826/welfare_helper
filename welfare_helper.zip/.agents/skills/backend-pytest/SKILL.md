---
name: backend-pytest
description: Implement and verify FastAPI backend changes with focused pytest checks. Use for Python endpoints, database access, errors, or backend tests.
---

# FastAPI and Pytest

1. Read the agreed interface and affected code before editing. The current application entrypoint is `BackEnd.main:app`; verify runtime and dependency settings in the repository.
2. Keep request flow and key branches visible. Avoid wrappers that merely forward calls, speculative abstractions, or unrelated refactoring.
3. Load configuration through runtime environment settings. Keep secrets out of errors and logs; close database connections and bound external requests.
4. Preserve existing API behavior unless an interface change is part of the task. Coordinate shared payload, schema, or authentication changes with affected parts.
5. Use pytest for normal flows and confirmed failures that need a regression check. Reuse existing tests; do not add tests that only mirror the implementation.
6. Use isolated data or controlled substitutes for write tests. Do not mutate production data or assume permission to migrate a cloud schema.
7. Run focused checks in the actual selected runtime. For simple reversible edits, use an appropriate existing test or static check.
8. Report what passed, what failed, and essential behavior not yet checked. Stop only processes started for the check.
