---
name: docker-workflow
description: Configure and operate this project's Docker Compose services while preserving data. Use for Dockerfiles, Compose, containers, volumes, and local runtime checks.
---

# Docker Workflow

1. Inspect relevant Compose and Dockerfile settings and distinguish existing services from services started for the task.
2. Use the repository root as the build context where the actual configuration requires it. Keep environment, ports, and data locations configurable.
3. Treat backend, PostgreSQL, and Ollama as separate services. Do not assume Compose services are deployed together on Vercel.
4. Use `.env.example` for configuration documentation. Let the runtime consume environment values; do not read or edit `.env`.
5. Preserve `postgres_data/`, `ollama_data/`, existing bind mounts, and volumes. Before changing a mount or database version, check compatibility and data retention.
6. Validate Compose configuration without printing resolved secrets. Build and exercise only affected services when verification requires it.
7. Check readiness and the relevant application response; a running container alone does not prove a working database or model connection.
8. Stop only services started for verification and confirm they stopped. Do not run volume deletion, prune, or database initialization as routine cleanup.
