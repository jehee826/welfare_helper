---
name: git-workflow
description: Manage project Git branches, commits, publication, and verified merged branch cleanup. Use for any Git mutation or pull request work.
---

# Git Workflow

1. Inspect status, current branch, relevant differences, remote, and worktrees. Preserve existing changes and do not mix another person's work into the task.
2. For implementation work, prepare a task branch from `main` when needed, without resetting the checkout or switching over conflicting changes. Reuse a suitable existing task branch.
3. Default branch naming is `codex/<type>-<kebab-case>`; use a user-specified convention when provided. Keep independent frontend and backend changes separate where useful.
4. Local branches, selective staging, and commits may be completed as part of the assigned work. Stage explicit paths or hunks; never use `git add .`, force-add ignored instructions, or include secrets.
5. Commit format: `<type>: <Korean summary>`. Types: feat, fix, docs, style, refactor, test, chore. Group one coherent change per commit. Use docs for independent documentation; supporting project maintenance may use chore.
6. Push, open PRs, merge, or publish directly to `main` when requested for the task. Reuse authorization already given; do not infer publication from an unrelated prior request.
7. PR base defaults to `main`; title format is `[Type] <Korean summary>`, with initial uppercase type. Explain behavior, relevant validation, and actual limitations. Order dependent work API → UI → styling when applicable.
8. Do not add AI attribution badges, text, or trailers, including `Co-authored-by:`, `Generated-by:`, and `Assisted-by:`.
9. Require specific authorization for destructive commands, force push, or rewriting published history. Do not use `reset --hard` or `clean` as routine cleanup.
10. After a verified merge, check remote merge state, ancestry or squash equivalence, remaining commits, uncommitted changes, and worktree use. Refresh main safely with fast-forward-only when suitable. Delete safe task branches using `branch -d` and remote deletion; preserve default, protected, unmerged, or uncertain branches.
11. Before publication, verify excluded instruction files, local skills, design documents, environment secrets, and persisted data are absent from staged changes.
