---
name: project-design
description: Define welfare chatbot requirements, screen guidance, interfaces, and implementation plans. Use for project design or changes to shared contracts.
---

# Project Design

1. Read the project brief and only the existing documents relevant to the requested part.
2. Identify confirmed requirements, current behavior, missing decisions, and affected consumers. Do not present a draft as agreed.
3. For screen guidance, describe the permitted capture source, image lifecycle, VLM input/output, failure behavior, and floating UI interaction. Do not add automated actions without a requirement.
4. Specify API payloads, errors, data access, and ownership where needed for implementation. Keep IDs and document links only where useful.
5. Use Korean Markdown documents under `docs/design/`. Create only requested or necessary documents; do not generate an entire document tree for a small task. Add actual local design documents or their dedicated folder to Git exclusions.
6. Resolve implementation details in the assigned part. Coordinate changes to other parts or shared contracts; continue independent work while a decision is pending.
7. Review requirement → interface/data → implementation → verification consistency. Update affected sections together.
8. Record project specifications and technical reasons, not chat history, approval records, or work journals.
