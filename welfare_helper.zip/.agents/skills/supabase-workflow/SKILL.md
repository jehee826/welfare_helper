---
name: supabase-workflow
description: Configure Supabase database connections, access controls, and migrations for the welfare chatbot. Use for Supabase, Postgres schema, authentication, or database connectivity.
---

# Supabase Workflow

1. Confirm the intended project and environment from current configuration or authenticated service metadata. Do not assume every connected project is the target.
2. Verify version-sensitive behavior using official Supabase documentation before changing integrations. Use available service tools, CLI, or APIs without assuming a particular connector exists.
3. For server database access, use the actual supported connection mode and verified host. Require TLS for deployed connections. Document variable names in `.env.example`; never print passwords or complete secret connection strings.
4. Keep server-only credentials on the backend. Design user identity, ownership, and Row Level Security for client-accessible user data; test access for the intended roles.
5. Use parameterized SQL and bounded queries. Review repeated I/O and indexes for actual query patterns rather than speculative tuning.
6. Coordinate shared schema changes and preserve existing data. Draft and validate migrations before applying them; confirm authorization for production mutations or destructive changes.
7. Use a read-only query such as `SELECT 1` for basic connectivity verification. Distinguish connection success from authentication, policy, schema, or feature correctness.
8. Do not upload screen images or store sensitive user data merely because storage is available. Apply the agreed retention and consent design.
