---
name: vercel-workflow
description: Link, configure, deploy, and verify the FastAPI project on Vercel. Use for Vercel project settings, environment variables, builds, deployments, and production checks.
---

# Vercel Workflow

1. Inspect the linked project, team, repository, runtime settings, and current deployment before changing anything. Reuse the existing intended project instead of creating a duplicate.
2. Check official Vercel documentation for current runtime support and CLI/API syntax. Use only actually available authenticated tools.
3. Verify the FastAPI entrypoint, Python compatibility, dependencies, and build ignore settings. Do not treat the local Docker Compose topology as a Vercel deployment.
4. Supply secrets through the correct project environment. Document names in `.env.example`; do not read `.env` or disclose secret values.
5. Prepare the complete reviewable change and local verification before publication. Deploy or promote when requested for the task; an environment variable change alone does not prove the running deployment received it.
6. Review build and runtime errors within the affected deployment. Fix the cause rather than disabling checks without a reason.
7. Verify deployment readiness and the intended endpoints. `/health` checks the app; `/health/db` checks basic DB connectivity when implemented. Verify chatbot or VLM flows separately when those features exist.
8. Handle deployment protection through supported authentication; do not weaken protection merely to make a check pass.
9. Report the actual deployed URL and verification outcome. Do not claim success solely from a deployment request being accepted.
